from eNMS.controller import App

app = App()
app.initialize()
