import { tables } from "../table.js";

$(document).ready(function () {
  // eslint-disable-next-line new-cap
  new tables["device"]("device");
});
