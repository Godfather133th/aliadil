from collections import defaultdict

models = {}
relationships = defaultdict(dict)
model_properties = defaultdict(lambda: ["type"])
property_types = {}
