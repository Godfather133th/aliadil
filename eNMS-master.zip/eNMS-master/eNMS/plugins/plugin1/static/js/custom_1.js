import { tables } from "/static/js/table.js";

$(document).ready(function () {
  // eslint-disable-next-line new-cap
  new tables["device"]("device");
});
