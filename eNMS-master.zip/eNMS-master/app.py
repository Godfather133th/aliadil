from eNMS.server import server as app  # noqa: F401
